﻿using CalculadoraAPI.Data; // Importa el espacio de nombres para el contexto de datos
using CalculadoraAPI.Models; // Importa los modelos necesarios
using Microsoft.AspNetCore.Mvc; // Proporciona funcionalidad para crear controladores de API
using Microsoft.EntityFrameworkCore; // Proporciona acceso a funciones de Entity Framework

namespace CalculadoraAPI.Controllers
{
    [Route("api/[controller]")] // Define la ruta base para el controlador, en este caso "api/Calculadora"
    [ApiController] // Especifica que este controlador es de tipo API
    public class CalculadoraController : ControllerBase
    {
        private readonly ApplicationDbContext _context; // Campo para interactuar con la base de datos

        // Constructor que inicializa el contexto de datos
        public CalculadoraController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Acción GET: api/Calculadora
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HistorialCalculos>>> GetAllCalculos()
        {

            var list = await _context.HistorialCalculos.OrderByDescending(h => h.FechaHora).ToListAsync();
            // Obtiene todas las operaciones ordenadas por fecha y hora de forma descendente
            return list;
        }

        // Acción GET: api/Calculadora/sumas
        [HttpGet("sumas")]
        public async Task<ActionResult<IEnumerable<HistorialCalculos>>> GetSumas()
        {
            // Obtiene operaciones de suma, filtrando por el carácter "+"
            return await _context.HistorialCalculos
                .Where(h => h.Operacion.Contains("+"))
                .OrderByDescending(h => h.FechaHora)
                .ToListAsync();
        }

        // Acción GET: api/Calculadora/restas
        [HttpGet("restas")]
        public async Task<ActionResult<IEnumerable<HistorialCalculos>>> GetRestas()
        {
            // Obtiene operaciones de resta, filtrando por el carácter "-"
            return await _context.HistorialCalculos
                .Where(h => h.Operacion.Contains("-"))
                .OrderByDescending(h => h.FechaHora)
                .ToListAsync();
        }

        // Acción GET: api/Calculadora/multiplicaciones
        [HttpGet("multiplicaciones")]
        public async Task<ActionResult<IEnumerable<HistorialCalculos>>> GetMultiplicaciones()
        {
            // Obtiene operaciones de multiplicación, filtrando por el carácter "*"
            return await _context.HistorialCalculos
                .Where(h => h.Operacion.Contains("*"))
                .OrderByDescending(h => h.FechaHora)
                .ToListAsync();
        }

        // Acción GET: api/Calculadora/divisiones
        [HttpGet("divisiones")]
        public async Task<ActionResult<IEnumerable<HistorialCalculos>>> GetDivisiones()
        {
            // Obtiene operaciones de división, filtrando por el carácter "/"
            return await _context.HistorialCalculos
                .Where(h => h.Operacion.Contains("/"))
                .OrderByDescending(h => h.FechaHora)
                .ToListAsync();
        }

        // Acción GET: api/Calculadora/especiales
        [HttpGet("especiales")]
        public async Task<ActionResult<IEnumerable<HistorialCalculos>>> GetOperacionesEspeciales()
        {
            // Obtiene operaciones especiales como raíces ("√") y potencias ("^")
            return await _context.HistorialCalculos
                .Where(h => h.Operacion.Contains("√") || h.Operacion.Contains("^"))
                .OrderByDescending(h => h.FechaHora)
                .ToListAsync();
        }

        // Acción POST: api/Calculadora
        [HttpPost]
        public async Task<ActionResult<HistorialCalculos>> PostCalculo(HistorialCalculos calculo)
        {
            // Asigna la fecha y hora actual al cálculo recibido
            calculo.FechaHora = DateTime.Now;
            // Agrega el cálculo al contexto de datos
            _context.HistorialCalculos.Add(calculo);
            // Guarda los cambios en la base de datos
            await _context.SaveChangesAsync();

            // Devuelve la ubicación del recurso creado (HTTP 201 Created)
            return CreatedAtAction(nameof(GetAllCalculos), new { id = calculo.Id }, calculo);
        }
    }
}
