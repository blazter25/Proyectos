﻿using Microsoft.AspNetCore.Http; // Importa funcionalidades relacionadas con HTTP
using Microsoft.AspNetCore.Mvc; // Proporciona herramientas para crear controladores y manejar peticiones

namespace CalculadoraAPI.Controllers
{
    // Controlador para manejar las solicitudes dirigidas a "Home"
    public class HomeController : Controller
    {
        // Acción GET para la ruta principal del controlador ("/Home" o simplemente "/")
        public ActionResult Index()
        {
            // Devuelve una vista al cliente (puede ser un archivo .cshtml que representa la interfaz)
            return View();
        }
    }
}
