﻿using CalculadoraAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CalculadoraAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<HistorialCalculos> HistorialCalculos { get; set; }
    }
}
