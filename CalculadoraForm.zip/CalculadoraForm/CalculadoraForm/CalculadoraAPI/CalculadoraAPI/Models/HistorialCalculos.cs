﻿namespace CalculadoraAPI.Models
{
    public class HistorialCalculos
    {
        public int Id { get; set; }
        public string Operacion { get; set; }
        public decimal Resultado { get; set; }
        public DateTime FechaHora { get; set; }
    }
}
