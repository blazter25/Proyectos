﻿namespace proy1
{
    partial class Form1
    {
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            txtResultado = new TextBox();
            button17 = new Button();
            button18 = new Button();
            btnVerHistorial = new Button(); // Nuevo botón
            label1 = new Label();
            SuspendLayout();

            // Form properties
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(500, 700);
            BackColor = Color.FromArgb(240, 240, 240);
            Font = new Font("Segoe UI", 12);
            Text = "Calculadora Moderna";

            // Label
            label1.AutoSize = true;
            label1.Location = new Point(170, 20);
            label1.Name = "label1";
            label1.Size = new Size(150, 32);
            label1.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            label1.Text = "Calculadora";
            Controls.Add(label1);

            // Textbox
            txtResultado.Location = new Point(20, 70);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(460, 50);
            txtResultado.Font = new Font("Segoe UI", 18);
            txtResultado.ReadOnly = true;
            txtResultado.TextAlign = HorizontalAlignment.Right;
            txtResultado.BackColor = Color.White;
            txtResultado.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(txtResultado);

            // Button 1
            button1.Location = new Point(20, 140);
            button1.Size = new Size(100, 50);
            button1.Font = new Font("Segoe UI", 14);
            button1.Text = "7";
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderColor = Color.Gray;
            button1.FlatAppearance.MouseOverBackColor = Color.LightGray;
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnNumero_Click;
            Controls.Add(button1);

            // Button 2
            button2.Location = new Point(130, 140);
            button2.Size = new Size(100, 50);
            button2.Font = new Font("Segoe UI", 14);
            button2.Text = "8";
            button2.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderColor = Color.Gray;
            button2.FlatAppearance.MouseOverBackColor = Color.LightGray;
            button2.UseVisualStyleBackColor = true;
            button2.Click += btnNumero_Click;
            Controls.Add(button2);

            // Button 3
            button3.Location = new Point(240, 140);
            button3.Size = new Size(100, 50);
            button3.Font = new Font("Segoe UI", 14);
            button3.Text = "9";
            button3.FlatStyle = FlatStyle.Flat;
            button3.FlatAppearance.BorderColor = Color.Gray;
            button3.FlatAppearance.MouseOverBackColor = Color.LightGray;
            button3.UseVisualStyleBackColor = true;
            button3.Click += btnNumero_Click;
            Controls.Add(button3);

            // Button 4
            button4.Location = new Point(350, 140);
            button4.Size = new Size(100, 50);
            button4.Font = new Font("Segoe UI", 14);
            button4.Text = "/";
            button4.FlatStyle = FlatStyle.Flat;
            button4.FlatAppearance.BorderColor = Color.Gray;
            button4.FlatAppearance.MouseOverBackColor = Color.LightGray;
            button4.UseVisualStyleBackColor = true;
            button4.Click += btnOperacion_Click;
            Controls.Add(button4);

            // Repeat similar definitions for the rest of the buttons
            button5.Location = new Point(20, 200);
            button5.Size = new Size(100, 50);
            button5.Font = new Font("Segoe UI", 14);
            button5.Text = "4";
            button5.Click += btnNumero_Click;
            Controls.Add(button5);

            button6.Location = new Point(130, 200);
            button6.Size = new Size(100, 50);
            button6.Font = new Font("Segoe UI", 14);
            button6.Text = "5";
            button6.Click += btnNumero_Click;
            Controls.Add(button6);

            button7.Location = new Point(240, 200);
            button7.Size = new Size(100, 50);
            button7.Font = new Font("Segoe UI", 14);
            button7.Text = "6";
            button7.Click += btnNumero_Click;
            Controls.Add(button7);

            button8.Location = new Point(350, 200);
            button8.Size = new Size(100, 50);
            button8.Font = new Font("Segoe UI", 14);
            button8.Text = "*";
            button8.Click += btnOperacion_Click;
            Controls.Add(button8);

            button9.Location = new Point(20, 260);
            button9.Size = new Size(100, 50);
            button9.Font = new Font("Segoe UI", 14);
            button9.Text = "1";
            button9.Click += btnNumero_Click;
            Controls.Add(button9);

            button10.Location = new Point(130, 260);
            button10.Size = new Size(100, 50);
            button10.Font = new Font("Segoe UI", 14);
            button10.Text = "2";
            button10.Click += btnNumero_Click;
            Controls.Add(button10);

            button11.Location = new Point(240, 260);
            button11.Size = new Size(100, 50);
            button11.Font = new Font("Segoe UI", 14);
            button11.Text = "3";
            button11.Click += btnNumero_Click;
            Controls.Add(button11);

            button12.Location = new Point(350, 260);
            button12.Size = new Size(100, 50);
            button12.Font = new Font("Segoe UI", 14);
            button12.Text = "-";
            button12.Click += btnOperacion_Click;
            Controls.Add(button12);

            button13.Location = new Point(20, 320);
            button13.Size = new Size(100, 50);
            button13.Font = new Font("Segoe UI", 14);
            button13.Text = "C";
            button13.Click += btnClear_Click;
            Controls.Add(button13);

            button14.Location = new Point(130, 320);
            button14.Size = new Size(100, 50);
            button14.Font = new Font("Segoe UI", 14);
            button14.Text = "0";
            button14.Click += btnNumero_Click;
            Controls.Add(button14);

            button15.Location = new Point(240, 320);
            button15.Size = new Size(100, 50);
            button15.Font = new Font("Segoe UI", 14);
            button15.Text = "=";
            button15.Click += btnIgual_Click;
            Controls.Add(button15);

            button16.Location = new Point(350, 320);
            button16.Size = new Size(100, 50);
            button16.Font = new Font("Segoe UI", 14);
            button16.Text = "+";
            button16.Click += btnOperacion_Click;
            Controls.Add(button16);

            button17.Location = new Point(20, 380);
            button17.Size = new Size(210, 50);
            button17.Font = new Font("Segoe UI", 14);
            button17.Text = "x²";
            button17.Click += btnOperacionEspecial_Click;
            Controls.Add(button17);

            button18.Location = new Point(240, 380);
            button18.Size = new Size(210, 50);
            button18.Font = new Font("Segoe UI", 14);
            button18.Text = "√";
            button18.Click += btnOperacionEspecial_Click;
            Controls.Add(button18);


            // Agregar el botón de historial (btnVerHistorial)
            btnVerHistorial.Location = new Point(20, 500); // Ajusta la posición según tu diseño
            btnVerHistorial.Size = new Size(460, 50);
            btnVerHistorial.Font = new Font("Segoe UI", 14);
            btnVerHistorial.Text = "Ver Historial";
            btnVerHistorial.FlatStyle = FlatStyle.Flat;
            btnVerHistorial.FlatAppearance.BorderColor = Color.Gray;
            btnVerHistorial.FlatAppearance.MouseOverBackColor = Color.LightGray;
            btnVerHistorial.UseVisualStyleBackColor = true;
            btnVerHistorial.Click += btnVerHistorial_Click;
            Controls.Add(btnVerHistorial);

            ResumeLayout(false);
            PerformLayout();
        }

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button btnVerHistorial; // Declaración del nuevo botón
        private TextBox txtResultado;
        private Label label1;
    }
}
