﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace proy1
{
    public partial class Form1 : Form
    {
        // Variables para almacenar el resultado y la operación actual
        private double resultado = 0;
        private string operacionActual = "";
        private bool operacionPresionada = false;

        public Form1()
        {
            InitializeComponent();
        }

        // Maneja el clic en los botones numéricos
        private void btnNumero_Click(object sender, EventArgs e)
        {
            // Limpia el campo de texto si se presionó una operación o si el texto es "0"
            if ((txtResultado.Text == "0") || operacionPresionada)
                txtResultado.Clear();

            operacionPresionada = false;

            // Agrega el número seleccionado al campo de texto
            Button boton = (Button)sender;
            txtResultado.Text += boton.Text;
        }

        // Maneja el clic en los botones de operación
        private void btnOperacion_Click(object sender, EventArgs e)
        {
            Button boton = (Button)sender;

            // Si hay un resultado previo, realiza la operación y actualiza el resultado
            if (resultado != 0)
            {
                btnIgual_Click(sender, e);
                operacionActual = boton.Text;
                operacionPresionada = true;
            }
            else
            {
                // Inicializa la nueva operación
                operacionActual = boton.Text;
                resultado = double.Parse(txtResultado.Text);
                operacionPresionada = true;
            }
        }

        // Maneja el clic en el botón de igual
        private void btnIgual_Click(object sender, EventArgs e)
        {
            // Obtiene los operandos y realiza la operación
            double segundoNumero = double.Parse(txtResultado.Text);
            string operacionCompleta = $"{resultado} {operacionActual} {segundoNumero}";
            double resultadoFinal = 0;

            // Calcula el resultado según la operación seleccionada
            switch (operacionActual)
            {
                case "+":
                    resultadoFinal = resultado + segundoNumero;
                    break;
                case "-":
                    resultadoFinal = resultado - segundoNumero;
                    break;
                case "*":
                    resultadoFinal = resultado * segundoNumero;
                    break;
                case "/":
                    // Verifica que no se esté dividiendo por cero
                    if (segundoNumero != 0)
                        resultadoFinal = resultado / segundoNumero;
                    else
                    {
                        MessageBox.Show("No se puede dividir entre 0.", "Error");
                        return;
                    }
                    break;
            }

            // Actualiza el campo de texto y el resultado
            txtResultado.Text = resultadoFinal.ToString();
            resultado = resultadoFinal;
            operacionActual = "";

            // Registra el cálculo en la base de datos
            RegistrarCalculo(operacionCompleta, resultadoFinal);
        }

        // Maneja el clic en el botón de borrado
        private void btnClear_Click(object sender, EventArgs e)
        {
            // Reinicia los valores
            txtResultado.Text = "0";
            resultado = 0;
            operacionActual = "";
        }

        // Maneja el clic en los botones de operaciones especiales
        private void btnOperacionEspecial_Click(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            double numero = double.Parse(txtResultado.Text);
            double resultadoOperacion = 0;
            string operacion = "";

            // Realiza la operación especial (cuadrado o raíz cuadrada)
            if (boton.Text == "x²")
            {
                resultadoOperacion = numero * numero;
                operacion = $"{numero} ^ 2";
            }
            else if (boton.Text == "√")
            {
                // Verifica que el número sea no negativo
                if (numero >= 0)
                {
                    resultadoOperacion = Math.Sqrt(numero);
                    operacion = $"√{numero}";
                }
                else
                {
                    MessageBox.Show("No se puede calcular la raíz cuadrada de un número negativo.", "Error");
                    return;
                }
            }

            // Actualiza el campo de texto y el resultado
            txtResultado.Text = resultadoOperacion.ToString();
            resultado = resultadoOperacion;

            // Registra el cálculo en la base de datos
            RegistrarCalculo(operacion, resultadoOperacion);
        }

        // Maneja el clic en el botón de ver historial
        private void btnVerHistorial_Click(object sender, EventArgs e)
        {
            try
            {
                // Conexión a la base de datos
                string connectionString = "Data Source=LAPTOP-5SAS35CE;Initial Catalog=CalculadoraDB;Integrated Security=True;";
                DataTable dataTable = new DataTable();

                // Obtiene los datos del historial de cálculos
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM HistorialCalculos ORDER BY FechaHora DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dataTable);
                        connection.Close();
                    }
                }

                // Crea una nueva ventana y muestra el historial
                Form historialForm = new Form();
                DataGridView dataGridView = new DataGridView
                {
                    DataSource = dataTable,
                    Dock = DockStyle.Fill
                };
                historialForm.Controls.Add(dataGridView);
                historialForm.Text = "Historial de Cálculos";
                historialForm.Size = new Size(600, 400);
                historialForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener el historial: {ex.Message}", "Error");
            }
        }

        // Registra un cálculo en la base de datos
        private void RegistrarCalculo(string operacion, double resultado)
        {
            string connectionString = @"Data Source=LAPTOP-5SAS35CE;Initial Catalog=CalculadoraDB;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO HistorialCalculos (Operacion, Resultado) VALUES (@Operacion, @Resultado)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Operacion", operacion);
                    command.Parameters.AddWithValue("@Resultado", resultado);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }
    }
}