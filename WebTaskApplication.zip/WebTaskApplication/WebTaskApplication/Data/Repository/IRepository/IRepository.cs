﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq.Expressions;

namespace WebTaskApplication.Data.Repository.IRepository
{
    public interface IRepository<T> where T : class
    {
        Task<T> Get(int id);
        Task<T> GetLast();
        Task<IEnumerable<T>> GetAll(
            Expression<Func<T, bool>>? filter = null,
            Func<IQueryable<T>, IOrderedQueryable<T>>? OrderBy = null,
            string? includeProperties = null, int? take = null);
        Task<bool> IsExist(Expression<Func<T, bool>>? filter = null);
        Task<T> GetFirstOrDefault(
            Expression<Func<T, bool>>? filter = null,
            string? includeProperties = null);
        void Add(T entity);
        void Remove(int id);
        void Remove(T entity);
        int Count(Expression<Func<T, bool>>? filter = null);
        SelectList GetSelectList(
            Expression<Func<T, bool>>? filter = null,
            string? property = null, int? value = null);
    }
}
