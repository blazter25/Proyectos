﻿namespace WebTaskApplication.Data.Repository.IRepository
{
    public interface ITasksRepository
    {

    }
}
