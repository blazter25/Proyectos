﻿using Microsoft.DotNet.Scaffolding.Shared;
using System.Collections.Generic;

namespace WebTaskApplication.Data.Repository.IRepository
{
    public interface IUnit : IDisposable
    {
       ITasksRepository TasksRepository { get; }
        void Save();
    }
}
