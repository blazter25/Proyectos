﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Linq;
using WebTaskApplication.Data.Repository.IRepository;

namespace WebTaskApplication.Data.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        protected readonly DbContext Context;
        internal DbSet<T> dbSet;
        public Repository(DbContext context)
        {
            Context = context;
            dbSet = Context.Set<T>();
        }

        public void Add(T entity)
        {
            dbSet.Add(entity);
        }

        public int Count(Expression<Func<T, bool>>? filter = null)
        {
            IQueryable<T> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }
            return query.ToList().Count;
        }

        public async Task<T> Get(int id)
        {
            return await dbSet.FindAsync(id);
        }

        public async Task<T> GetLast()
        {
            return await dbSet.MaxAsync();
        }

        public async Task<IEnumerable<T>> GetAll(Expression<Func<T, bool>>? filter = null, Func<IQueryable<T>, IOrderedQueryable<T>>? OrderBy = null, string? includeProperties = null, int? take = null)
        {
            IQueryable<T> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            if (OrderBy != null)
            {
                if (take != null)
                {
                    return OrderBy(query).Take(take.GetValueOrDefault()).ToList();
                }
                else
                {
                    return OrderBy(query).ToList();
                }

            }
            if (take != null)
            {
                query = query.Take(take.GetValueOrDefault());
            }
            return await query.ToListAsync();
        }

        public async Task<bool> IsExist(Expression<Func<T, bool>>? filter = null)
        {
            if (filter is not null)
            {
                return await dbSet.AnyAsync(filter);
            }
            return false;
        }

        public async Task<T> GetFirstOrDefault(Expression<Func<T, bool>>? filter = null, string? includeProperties = null)
        {
            IQueryable<T> query = dbSet;
            if (filter != null)
            {
                query = query.Where(filter);
            }
            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }
            return await query.FirstOrDefaultAsync();
        }

        public void Remove(int id)
        {
            T entityToRemove = dbSet.Find(id);
            if (entityToRemove is not null)
            {
                Remove(entityToRemove);
            }

        }

        public void Remove(T entity)
        {
            dbSet.Remove(entity);
        }

        public SelectList GetSelectList(
            Expression<Func<T, bool>>? filter = null,
            string? property = null,
            int? value = null)
        {
            string Property = "Name";
            IQueryable<T> query = dbSet;

            if (filter != null)
                query = query.Where(filter);

            if (property != null)
                Property = property;

            if (value != null)
                return new SelectList(query, "Id", Property, value);

            return new SelectList(query, "Id", Property);
        }
    }
}
