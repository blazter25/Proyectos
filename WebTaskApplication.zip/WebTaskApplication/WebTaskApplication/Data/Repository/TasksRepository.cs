﻿using WebTaskApplication.Data.Repository.IRepository;
using WebTaskApplication.Models;

namespace WebTaskApplication.Data.Repository
{
    public class TasksRepository : Repository<Tasks>, ITasksRepository
    {
        private readonly ApplicationDbContext _db;
        public TasksRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }
        public void Update(Tasks tasks)
        {
            var objFromDb = _db.Tasks.FirstOrDefault(m => m.ID == tasks.ID);
            objFromDb.TaskName = tasks.TaskName;
            objFromDb.Status = tasks.Status;
            objFromDb.DueDate = tasks.DueDate;
            objFromDb.CreatedAt = tasks.CreatedAt;
            objFromDb.UpdatedAt = tasks.UpdatedAt;
            objFromDb.CompletedAt= tasks.CompletedAt;
            objFromDb.Description = tasks.Description;
            objFromDb.Priority = tasks.Priority;
            objFromDb.AssignedTo = tasks.AssignedTo;
            _db.SaveChanges();
        }
    }
}
