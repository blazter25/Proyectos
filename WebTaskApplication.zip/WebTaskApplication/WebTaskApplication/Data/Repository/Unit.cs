﻿using Microsoft.DotNet.Scaffolding.Shared;
using System.Collections.Generic;
using WebTaskApplication.Data.Repository.IRepository;

namespace WebTaskApplication.Data.Repository
{
    public class Unit : IUnit
    {
        private readonly ApplicationDbContext _db;
        public ITasksRepository TasksRepository { get; private set; }

        public Unit(ApplicationDbContext db)
        {
            _db = db;
            TasksRepository = new TasksRepository(_db);
        }
        public void Dispose()
        {
            _db.Dispose();
            GC.SuppressFinalize(this);
        }
        public void Save()
        {
            _db.SaveChanges();
        }

    }
}
