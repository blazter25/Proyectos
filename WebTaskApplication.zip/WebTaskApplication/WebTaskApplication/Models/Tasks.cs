﻿using System.ComponentModel.DataAnnotations;

namespace WebTaskApplication.Models
{
    public class Tasks
    {
        public int ID { get; set; }

        [Display(Name = "Nombre de la Tarea")]
        public string TaskName { get; set; } = null!;

        [Display(Name = "Descripción")]
        public string? Description { get; set; }

        [Display(Name = "Asignado a")]
        public string? AssignedTo { get; set; }

        [Display(Name = "Prioridad")]
        public string Priority { get; set; } = null!;

        [Display(Name = "Estado")]
        public string Status { get; set; } = null!;

        [Display(Name = "Fecha Límite")]
        public DateTime? DueDate { get; set; }

        [Display(Name = "Fecha de Creación")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Display(Name = "Última Actualización")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [Display(Name = "Fecha de Finalización")]
        public DateTime? CompletedAt { get; set; }
    }

}
